fun main() {
    val charArray = readLine()!!.toCharArray()

   // print char array
   for (i in charArray)
       println(i)
}