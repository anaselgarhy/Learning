package com.example.clothingstore

class components (var name: String, var salary: Int, var img: Int){
}